#ifndef DNA_H
#define DNA_H
#include "Sequence.h"
#include "RNA.h"

class RNA;

enum DNA_Type {promoter, motif, tail, noncoding, nonDNA};

class DNA : public Sequence
{
private:
    DNA_Type type;
    DNA* Complementary_Strand;
    int StartIndex;
    int EndIndex;

public:

    /// Constructors and Destructor
    DNA();
    DNA(char* s, DNA_Type t);
    DNA(DNA& rhs);
    ~DNA();

    /// Setter and Getter functions for the DNA Sequence
    void SetSeq(char* SEQ);
    char* GetSeq();
    int Getlength();
    void SetSeq(char x, int i);
    char GetChar(int i);
    char* GetComplementaryStrand();
    char GetComplementaryStrandChar(int i);

    /// Start and End indexes Setters and Getters functions
    void SetStart(int i);
    void SetEnd(int i);
    int GetStart();
    int GetEnd();

    /// DNA Type setter and getters
    void SetType(DNA_Type t);
    DNA_Type GetType();

    void Print();   /// A Function that prints The sequence of The DNA and its type

    void BuildComplementaryStrand();    /// A Function that builds the second strand of the DNA sequence

    RNA ConvertToRNA();    /// A Function that converts the DNA to RNA

    /// Save sequence to file and Load sequence from file functions
    void LoadSequenceFromFile(char FileName[100]);
    void SaveSequenceToFile(char FileName[100]);

    /// Overloaded operators
    friend ostream&operator<< (ostream& out, const DNA& d);
    friend istream&operator>> (istream& in, DNA& d);
    DNA operator= (DNA& d);
    DNA operator+ (const DNA& d);
    bool operator== (DNA& d);
    bool operator!= (DNA& d);
};


#endif // DNA_H
