#ifndef PROTEIN_H
#define PROTEIN_H
#include "DNA.h"
#include "Sequence.h"
class DNA;
enum Protein_Type {Hormon, Enzyme, TF, Cellular_Function, nonProtein};

class Protein : public Sequence
{
private:
    Protein_Type type;
public:

    /// Constructors and Destructor
    Protein();
    Protein(char* s, Protein_Type t);
    ~Protein();

    /// Setter and Getter functions for the Protein Sequence
    void SetSeq(char* s);
    char* GetSeq();
    void SetSeq(char x, int i);

    /// Protein Type setter and getter functions
    void SetType(Protein_Type t);
    Protein_Type GetType();

    /// Save sequence to file and Load sequence from file functions
    void LoadSequenceFromFile(char FileName[100]);
    void SaveSequenceToFile(char FileName[100]);

    /// return an array of DNA sequences that can possibly
            /// generate that protein sequence
    DNA GetDNAStrandsEncodingMe(DNA bigDNA);

    void Print();   /// A Function that prints the sequence of the Protein and its type

    /// Overloaded operators
    friend ostream&operator<< (ostream& out, const Protein& p);
    friend istream&operator>> (istream& in, Protein& p);
    Protein operator= (Protein& p);
    Protein operator+ (const Protein& p);
    bool operator== (Protein& p);
    bool operator!= (Protein& p);
};


#endif // PROTEIN_H
