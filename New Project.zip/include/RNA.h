#ifndef RNA_H
#define RNA_H
#include "DNA.h"
#include "Sequence.h"
#include "Protein.h"
#include "Codons Table.h"

class DNA;
class CodonsTable;
class Protein;
enum RNA_Type {mRNA, pre_mRNA, mRNA_exon, mRNA_intron, nonRNA};

class RNA : public Sequence
{
private:
    RNA_Type type;
public:

    /// Constructors and Destructor
    RNA();
    RNA(char* s, RNA_Type t);
    RNA(RNA& rhs);
    ~RNA();

    /// Setter and Getter functions for the RNA Sequence
    void SetSeq(char* SEQ);
    char* GetSeq();
    int Getlength();
    void SetSeq(char x, int i);
    char GetChar(int i);

    /// RNA Type setter and getter functions
    void SetType (RNA_Type t);
    RNA_Type GetType();


    /// Save sequence to file and Load sequence from file functions
    void LoadSequenceFromFile(char FileName[100]);
    void SaveSequenceToFile(char FileName[100]);

    void Print();   /// A Function that prints the sequence of the RNA and its type

    /// function to convert the RNA sequence into protein sequence
    /// using the codonsTable object
    Protein ConvertToProtein(CodonsTable& table);

    /// function to convert the RNA sequence back to DNA
    DNA ConvertToDNA();

    /// Overloaded operators
    friend ostream&operator<< (ostream& out, const RNA& r);
    friend istream&operator>> (istream& in, RNA& r);
    RNA operator= (RNA& r);
    RNA operator+ (const RNA& r);
    bool operator== (RNA& r);
    bool operator!= (RNA& r);
};


#endif // RNA_H
