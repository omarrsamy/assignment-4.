#ifndef SEQUENCE_H
#define SEQUENCE_H
#include <iostream>
#include <cstring>
using namespace std;


class Sequence
{
    protected:
    char *seq;

public:

    /// constructors and destructor
    Sequence();
    Sequence(int length);
    Sequence(Sequence& rhs);
    virtual ~Sequence();

    /// pure virtual functions
    virtual void Print() = 0;
    virtual void SetSeq(char* SEQ) = 0;
    virtual char* GetSeq() = 0;
    virtual void LoadSequenceFromFile(char FileName[100]) = 0;
    virtual void SaveSequenceToFile(char FileName[100]) = 0;

    // pure virtual function that MUST be overridden because every
    // sequence
    // type of sequence has its own way to be aligned with another
    friend char* Align(Sequence* s1, Sequence* s2);
    friend ostream&operator<< (ostream& out, Sequence* s);
    friend istream&operator>> (istream& in, Sequence* s);
};


#endif // SEQUENCE_H
