#include <iostream>
#include <fstream>
#include "Codons Table.h"
using namespace std;

CodonsTable::CodonsTable()
{
    LoadCodonsFromFile("RNA_codon_table");
}

void CodonsTable::LoadCodonsFromFile(string s)
{
    s = "RNA_codon_table.txt";
    ifstream DataFile;
    DataFile.open("RNA_codon_table.txt", ios::in);
    if(DataFile.fail()){
        cout << " File opening failed" << endl;
    }
    int i = 0;
    char temp[4];
    char tempAminoAcid;
    while(!DataFile.eof()){
        DataFile >> temp >> tempAminoAcid;
        codons[i].value[0] = temp[0];
        codons[i].value[1] = temp[1];
        codons[i].value[2] = temp[2];
        codons[i].value[3] = '\0';
        codons[i].AminoAcid = tempAminoAcid;
        i++;
    }
    DataFile.close();
}

Codon CodonsTable::getAminoAcid(char* value)
{
    Codon C;
    C.value[0] = value[0];
    C.value[1] = value[1];
    C.value[2] = value[2];
    C.value[3] = '\0';
    for(int i = 0; i < 64; i++){
        if(C.value[0] == codons[i].value[0] && C.value[1] == codons[i].value[1] && C.value[2] == codons[i].value[2]){
            C.AminoAcid = codons[i].AminoAcid;
        }
    }
    return C;
}

void CodonsTable::setCodon(char* value, char AminoAcid, int index)
{
    Codon C;
    C.value[0] = value[0];
    C.value[1] = value[1];
    C.value[2] = value[2];
    C.value[3] = '\0';
    C.AminoAcid = AminoAcid;
    codons[index] = C;
}

Codon CodonsTable::GetCodon(const int i)
{
    Codon C;
    C.value[0] = codons[i].value[0];
    C.value[1] = codons[i].value[1];
    C.value[2] = codons[i].value[2];
    C.AminoAcid = codons[i].AminoAcid;
}

CodonsTable::~CodonsTable()
{
    /// Destructor
}
