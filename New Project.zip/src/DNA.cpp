#include <iostream>
#include <fstream>
#include <cstring>
#include "DNA.h"
#include "RNA.h"
#include "string.h"

using namespace std;

DNA::DNA()
{
    type = nonDNA;
    seq = new char[0];
    int StartIndex = 0;
    int EndIndex = 0;
}

DNA::DNA(char* s, DNA_Type t)
{
    seq = new char [strlen(s)];
    type = t;
    StartIndex = 0;
    EndIndex = strlen(seq) - 1;
    Complementary_Strand = new DNA;
    for(int i=0; i<strlen(s); i++){
        seq[i] = s[i];
        seq[i+1] = '\0';
    }
    BuildComplementaryStrand();
}

DNA::DNA(DNA& rhs)
{
    seq = new char [strlen(rhs.seq)];
    Complementary_Strand = rhs.Complementary_Strand;
    type = rhs.type;
    StartIndex = rhs.StartIndex;
    EndIndex = rhs.EndIndex;
    for(int i = 0; i < strlen(rhs.seq); i++){
        seq[i] = rhs.seq[i];
        seq[i+1] = '\0';
    }
}

DNA::~DNA()
{
   delete []seq;
}

void DNA::SetSeq(char* SEQ)
{
    seq = new char [strlen(SEQ)];
    for (int i = 0 ; i < strlen(SEQ); i++){
        seq[i] = SEQ[i];
        seq[i+1] = '\0';
    }

}

char* DNA::GetSeq()
{
    return seq;
}

int DNA::Getlength()
{
    return strlen(seq);
}

void DNA::SetSeq(char x, int i)
{
    seq[i] = x;
    BuildComplementaryStrand();
}

char DNA::GetChar(int i)
{
    return seq[i];
}

char* DNA::GetComplementaryStrand()
{
    return Complementary_Strand->seq;
}

char DNA::GetComplementaryStrandChar(int i)
{
    return Complementary_Strand->seq[i];
}

void DNA::SetStart(int i)
{
    StartIndex = i;
}

void DNA::SetEnd(int i)
{
    EndIndex = i;
}

int DNA::GetStart()
{
    return StartIndex;
}

int DNA::GetEnd()
{
    return EndIndex;
}

void DNA::Print()
{
    cout << " The DNA Sequence: " << seq << "\n The Complementary Strand: " << Complementary_Strand->seq << endl;
    if(type == 0)
    cout << " Its Type: promoter" << endl;
    else if(type == 1)
    cout << " Its Type: motif" << endl;
    else if(type == 2)
    cout << " Its Type: tail" << endl;
    else if(type == 3)
    cout << " Its Type: non_coding" << endl;
    else
    cout << "non DNA type." << endl;
}

void DNA::SetType(DNA_Type t)
{
    type = t;
}

DNA_Type DNA::GetType()
{
    return type;
}

void DNA::BuildComplementaryStrand()
{
    for(int i = 0; i < strlen(seq); i++){
        if(seq[i] == 'A'){
            Complementary_Strand->seq[i] = 'T';
            Complementary_Strand->seq[i+1] = '\0';
        }
        if(seq[i] == 'T'){
            Complementary_Strand->seq[i] = 'A';
            Complementary_Strand->seq[i+1] = '\0';
        }
        if(seq[i] == 'C'){
            Complementary_Strand->seq[i] = 'G';
            Complementary_Strand->seq[i+1] = '\0';
        }
        if(seq[i] == 'G'){
            Complementary_Strand->seq[i] = 'C';
            Complementary_Strand->seq[i+1] = '\0';
        }
    }
}

RNA DNA::ConvertToRNA()
{
    RNA r;
    for(int i = 0; i < strlen(Complementary_Strand->seq); i++){
        if(Complementary_Strand->seq[i] == 'T'){
            r.SetSeq('U', i);
            r.SetSeq('\0', i+1);
        }
        else{
            r.SetSeq(Complementary_Strand->seq[i], i);
        }
    }
    r.SetType(mRNA);
    return r;
}

void DNA::LoadSequenceFromFile(char FileName[100])
{
    int choice;
    cout << " Enter the type of the DNA in the file: \n 1- Promoter.\n 2- Motif.\n 3- Tail.\n 4- Noncoding.";
    cin >> choice;
    if(choice == 1){
        type = promoter;
    }
    if(choice == 2){
        type = motif;
    }
    if(choice == 3){
        type = tail;
    }
    if(choice == 4){
        type = noncoding;
    }
    fstream DataFile(FileName);
    if(DataFile.fail()){
        cout << " File opening failed!" << endl;
    }

    int i = 0;
    while(!DataFile.eof()){
        DataFile >> seq[i];
        seq[i+1] = '\0';
        i++;
    }
    BuildComplementaryStrand();
    DataFile.close();
}

void DNA::SaveSequenceToFile(char FileName[100])
{
    ofstream DataFile;
    DataFile.open(FileName, ios::app);
    DataFile << "The DNA Sequence: " << seq << endl;
    DataFile << "The Complementary Strand: " << Complementary_Strand->seq << endl;
    if(type == 0){
        DataFile << "The type: promoter" << endl;
    }
    else if(type == 1){
        DataFile << "The type: motif" << endl;
    }
    else if(type == 2){
        DataFile << "The type: tail" << endl;
    }
    else if(type==3){
        DataFile << "The type: noncoding" << endl;
    }
    else{
        DataFile << "Non DNA type" << endl;
    }
    DataFile << endl;
    DataFile.close();
}

istream&operator>> (istream& in, DNA& d)
{
    cout << " Enter the start index: ";
    in >> d.StartIndex;
    cout << " Enter end index: ";
    in >> d.EndIndex;
    cout << " Enter The type: \n 1- Promoter.\n 2- Motif.\n 3- Tail.\n 4- Noncoding." << endl;
    int TYPE;
    in >> TYPE;
    if(TYPE == 1){
        d.type = promoter;
    }
    if(TYPE == 2){
        d.type = motif;
    }
    if(TYPE == 3){
        d.type = tail;
    }
    if(TYPE == 4){
        d.type = noncoding;
    }
    int length;
    cout << " Enter the length of the sequence: ";
    in >> length;
    d.seq = new char[length];
    try
    {
        for(int i = 0; i < length; i++){
            in >> d.seq[i];
            if(d.seq[i] == 'A' || d.seq[i] == 'T' || d.seq[i] == 'G' || d.seq[i] == 'C'){
                d.seq[i+1] = '\0';
                if(i == length - 1){
                    for(int k = 0; k < strlen(d.seq); k++){
                        if(d.seq[k] == 'A'){
                            d.Complementary_Strand->seq[k] = 'T';
                            d.Complementary_Strand->seq[k+1] = '\0';
                        }
                        if(d.seq[k] == 'T'){
                            d.Complementary_Strand->seq[k] = 'A';
                            d.Complementary_Strand->seq[i+1] = '\0';
                        }
                        if(d.seq[k] == 'C'){
                            d.Complementary_Strand->seq[k] = 'G';
                            d.Complementary_Strand->seq[k+1] = '\0';
                        }
                        if(d.seq[k] == 'G'){
                            d.Complementary_Strand->seq[k] = 'C';
                            d.Complementary_Strand->seq[k+1] = '\0';
                        }
                    }
                }
            }
            else{
                string error = " Wrong input!";
                throw error;
            }
        }
    }
    catch(string error)
    {
        cout << error << endl;
    }
    return in;
}

ostream&operator<< (ostream& out, const DNA& d)
{
    out << " The DNA Sequence : ";
    for(int i = 0; i < strlen(d.seq); i++){
        out << d.seq[i];
    }
    out << endl;
    out << " The Complementary Strand: ";
    out << d.Complementary_Strand->seq << endl;
    out << " Its Type: ";
    if(d.type == 0){
        out << "promoter" << endl;
    }
    else if(d.type == 1){
        out << "motif" << endl;
    }
    else if(d.type == 2){
        out << "tail" << endl;
    }
    else if(d.type == 3){
        out << "non_coding" << endl;
    }
    else{
        out << "non DNA type" << endl;
    }
    return out;
}

DNA DNA::operator= (DNA& d)
{
    seq = d.seq;
    type = d.type;
}

DNA DNA::operator+ (const DNA& d)
{
    if(type == d.type){
        DNA NewDNA("\0", type);
        strcat(NewDNA.seq, seq);
        strcat(NewDNA.seq, d.seq);
        NewDNA.BuildComplementaryStrand();
        return NewDNA;
    }
    else{
        cout << " The 2 DNA are not of the same type!" << endl;
    }
}

bool DNA::operator== (DNA& d)
{
    bool check = true;
    if(strlen(seq) != strlen(d.seq)){
        check = false;
    }
    else{
        for(int i = 0; i < strlen(seq); i++){
            if(seq[i] != d.seq[i]){
                check = false;
            }
        }
    }
    return check;
}

bool DNA::operator!= (DNA& d)
{
    bool check = true;
    if(strlen(seq) != strlen(d.seq)){
        check = true;
    }
    else{
        for(int i = 0; i < strlen(seq); i++){
            if(seq[i] == d.seq[i]){
                check = false;
            }
        }
    }
    return check;
}

