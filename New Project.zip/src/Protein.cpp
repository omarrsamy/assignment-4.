#include <fstream>
#include <iostream>
#include "Protein.h"
#include "DNA.h"

using namespace std;

Protein::Protein()
{
    type = nonProtein;
    seq = new char[0];
}
Protein::Protein(char* p, Protein_Type t)
{
    seq = new char [strlen(p)];
    type = t;
    for(int i = 0; i < strlen(p); i++)
    {
        seq[i] = p[i];
        seq[i+1] = '\0';
    }
}

Protein::~Protein()
{
     delete []seq;
}

void Protein::SetSeq(char* s)
{
    seq = new char[strlen(s)];
    for(int i = 0; i < strlen(s); i++){
        seq[i] = s[i];
        seq[i+1] = '\0';
    }
}

char* Protein::GetSeq()
{
    return seq;
}

void Protein::SetSeq(char x, int i)
{
    seq[i] = x;
}

void Protein::SetType(Protein_Type t)
{
    type = t;
}

Protein_Type Protein::GetType()
{
    return type;
}

void Protein::LoadSequenceFromFile(char FileName[100])
{
    ifstream DataFile;
    DataFile.open(FileName, ios::in);
    if(DataFile.fail()){
        cout << " File opening failed!" << endl;
    }
    int i = 0;
    while(!DataFile.eof()){
        DataFile >> seq[i];
        seq[i+1] = '\0';
        i++;
    }
    int choice;
    cout << " Enter the type of the Protein in the file: \n 1- Hormone.\n 2- Enzyme.\n 3- TF.\n 4- Cellular Function.";
    cin >> choice;
    if(choice == 1){
        type = Hormon;
    }
    if(choice == 2){
        type = Enzyme;
    }
    if(choice == 3){
        type = TF;
    }
    if(choice == 4){
        type = Cellular_Function;
    }
    DataFile.close();
}

void Protein::SaveSequenceToFile(char FileName[100])
{
    ofstream DataFile;
    DataFile.open(FileName, ios::app);
    DataFile << "The Protein sequence: " << seq << endl;
    if(type == 0){
        DataFile << "The type: Hormone" << endl;
    }
    else if(type == 1){
        DataFile << "The type: Enzyme" << endl;
    }
    else if(type == 2){
        DataFile << "The type: TF" << endl;
    }
    else if(type == 3){
        DataFile << "The type: Cellular Function" << endl;
    }
    else{
        DataFile << "Non Protein type" << endl;
    }
    DataFile << endl;
    DataFile.close();

}

DNA Protein::GetDNAStrandsEncodingMe(DNA bigDNA)
{

}

void Protein::Print()
{
    cout << "\n The Protein Sequence: " << seq << endl;
    if(type == 0){
        cout << " The Type: Hormone"<<endl;
    }
    else if(type == 1){
        cout << " The Type: Enzyme" << endl;
    }
    else if(type == 2){
        cout << " The Type: TF" << endl;
    }
    else if(type == 3){
        cout << " The Type: Cellular Function" << endl;
    }
    else{
        cout << " The Type: non Protein type" << endl;
    }
}

ostream&operator<<(ostream& out , const Protein& p)
{
    out << " The Protein Sequence : ";
    for(int i = 0; i < strlen(p.seq); i++){
        out << p.seq[i];
    }
    out << endl;
    out << " Its Type: ";
    if(p.type == 0){
        out << "Hormone" << endl;
    }
    else if(p.type == 1){
        out << "Enzyme" << endl;
    }
    else if(p.type == 2){
        out << "TF" << endl;
    }
    else if(p.type == 3){
        out << "Cellular Function" << endl;
    }
    else{
        out << "non Protein type" << endl;
    }
    return out;
}

istream&operator>>(istream& in , Protein& p)
{
    cout << " Enter The type: \n 1- Hormone.\n 2- Enzyme.\n 3- TF.\n 4- Cellular_Function.";
    int TYPE;
    in >> TYPE;
    if(TYPE == 1){
        p.SetType(Hormon);
    }
    if(TYPE == 2){
        p.SetType(Enzyme);
    }
    if(TYPE == 3){
        p.SetType(TF);
    }
    if(TYPE == 4){
        p.SetType(Cellular_Function);
    }
    cout << " Enter the number of Amino Acids you need to enter: ";
    int length;
    in >> length;
    try
    {
        for(int i = 0; i < length; i++){
            in >> p.seq[i];
            if(p.seq[i] == 'K' || p.seq[i] == 'N' || p.seq[i] == 'T' || p.seq[i] == 'R' || p.seq[i] == 'S' || p.seq[i] == 'I' || p.seq[i] == 'M' || p.seq[i] == 'Q' || p.seq[i] == 'H' || p.seq[i] == 'P' || p.seq[i] == 'L' || p.seq[i] == 'E' || p.seq[i] == 'D' || p.seq[i] == 'A' || p.seq[i] == 'G' || p.seq[i] == 'V' || p.seq[i] == 'Y' || p.seq[i] == 'C' || p.seq[i] == 'W' || p.seq[i] == 'F'){
                p.seq[i+1] = '\0';
            }
            else{
                string error = " Wrong input!";
                throw error;
            }
        }
    }
    catch(string error)
    {
        cout << error << endl;
    }
    return in;
}

Protein Protein::operator= (Protein& p)
{
    seq = p.seq;
    type = p.type;
}

Protein Protein::operator+ (const Protein& p)
{
    if(type == p.type){
        Protein NewProtein("\0", type);
        strcat(NewProtein.seq, seq);
        strcat(NewProtein.seq, p.seq);
        return NewProtein;
    }
    else{
        cout << " The 2 Proteins are not of the same type!" << endl;
    }
}
bool Protein::operator== (Protein & p)
{
    bool check = true;
    if(strlen(seq) != strlen(p.seq)){
        check = false;
    }
    else{
        for(int i = 0; i < strlen(seq); i++){
            if(seq[i] != p.seq[i]){
                check = false;
            }
        }
    }
    return check;
}

bool Protein::operator !=(Protein & p)
{
    bool check = true;
    if(strlen(seq) != strlen(p.seq)){
        check = true;
    }
    else{
        for(int i = 0; i < strlen(seq); i++){
            if(seq[i] == p.seq[i]){
                check = false;
            }
        }
    }
    return check;
}
