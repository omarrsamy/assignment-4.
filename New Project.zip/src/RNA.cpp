#include <fstream>
#include <iostream>
#include "RNA.h"
#include "DNA.h"
#include "Codons Table.h"
#include "Sequence.h"
#include "Protein.h"

using namespace std;

class Protein;

RNA::RNA()
{
    type = nonRNA;
    seq = new char[0];
}

RNA::RNA(char* s, RNA_Type t)
{
    seq = new char[strlen(s)];
    type = t;
    for(int i = 0; i < strlen(s); i++){
        seq[i] = s[i];
        seq[i+1] = '\0';
    }
}

RNA::RNA(RNA& rhs)
{
    seq = new char[strlen(rhs.seq)];
    type = rhs.type;
    for(int i = 0; i < strlen(rhs.seq); i++){
        seq[i] = rhs.seq[i];
        seq[i+1] = '\0';
    }
}

RNA::~RNA()
{
    delete []seq;
}

void RNA::SetSeq(char* SEQ)
{
    seq = new char [strlen(SEQ)];
    for(int i = 0; i < strlen(SEQ); i++){
        seq[i] = SEQ[i];
        seq[i+1] = '\0';
    }
}

char* RNA::GetSeq()
{
    return seq;
}

int RNA::Getlength()
{
    return strlen(seq);
}

void RNA::SetSeq(char x, int i)
{
    seq[i] = x;
}

char RNA::GetChar(int i)
{
    return seq[i];
}

void RNA::SetType(RNA_Type t)
{
    type = t;
}

RNA_Type RNA::GetType ()
{
    return type;
}

void RNA::LoadSequenceFromFile(char FileName[100])
{
    int choice;
    cout << " Enter the type of the RNA in the file: \n 1- mRNA.\n 2- pre_mRNA.\n 3- mRNA_exon.\n 4- mRNA_intron.";
    cin >> choice;
    if(choice == 1){
        type = mRNA;
    }
    if(choice == 2){
        type = pre_mRNA;
    }
    if(choice == 3){
        type = mRNA_exon;
    }
    if(choice == 4){
        type = mRNA_intron;
    }
    fstream DataFile(FileName);
    if(DataFile.fail()){
        cout << " File opening failed!" << endl;
    }

    int i = 0;
    while(!DataFile.eof()){
        DataFile >> seq[i];
        seq[i+1] = '\0';
        i++;
    }
    DataFile.close();
}

void RNA::SaveSequenceToFile(char FileName[100])
{
    ofstream DataFile;
    DataFile.open(FileName, ios::app);
    DataFile << "The RNA Sequence: " << seq << endl;
    if(type == 0){
        DataFile << "The type: mRNA" << endl;
    }
    else if(type == 1){
        DataFile << "The type: pre_mRNA" << endl;
    }
    else if(type == 2){
        DataFile << "The type: mRNA_exon" << endl;
    }
    else if(type == 3){
        DataFile << "The type: mRNA_intron" << endl;
    }
    else{
        DataFile << "Non RNA type" << endl;
    }
    DataFile << endl;
    DataFile.close();
}

void RNA::Print()
{
    cout << "\n The RNA Sequence: " << seq << endl;
    if(type == 0){
        cout << " The type: mRNA" << endl;
    }
    else if(type == 1){
        cout << " The type: pre_mRNA" << endl;
    }
    else if(type == 2){
        cout << " The Type: mRNA_exon"<<endl;
    }
    else if(type == 3){
        cout << " The type: mRNA_intron" << endl;
    }
    else{
        cout << " non RNA type" << endl;
    }
}

DNA RNA::ConvertToDNA()
{
    char* SEQ = new char[strlen(seq)];
    for(int i = 0; i < strlen(seq); i++){
        if(seq[i] == 'U'){
            SEQ[i] = 'T';
            SEQ[i+1] = '\0';
        }
        else{
            SEQ[i] = seq[i];
            SEQ[i+1] = '\0';
        }
    }
    DNA NewDNA(SEQ, promoter);
    return NewDNA;
}

Protein RNA::ConvertToProtein(CodonsTable& table)
{
    char* temp = new char[strlen(seq) / 3];
    char* arr = new char[4];
    int k = 0;
    for(int i = 0; i < strlen(seq); i += 3){
        arr[0] = seq[i];
        arr[1] = seq[i+1];
        arr[2] = seq[i+2];
        arr[3] = '\0';
        for(int j = 0; j < 64; j++){
            Codon C;
            C = table.GetCodon(j);
            if(arr[0] == C.value[0] && arr[1] == C.value[1] && arr[2] == C.value[2]){
                temp[k] = C.AminoAcid;
                k++;
            }
        }
    }
    Protein NewProtein(temp, Cellular_Function);
    delete []arr;
    delete []temp;
    return NewProtein;
}

ostream&operator<< (ostream& out, const RNA& r)
{
    out << " The DNA Sequence : ";
    for(int i = 0; i < strlen(r.seq); i++){
        out << r.seq[i];
    }
    out << endl;
    out << " Its Type: ";
    if(r.type == 0){
        out << "mRNA" << endl;
    }
    else if(r.type == 1){
        out << "pre_mRNA" << endl;
    }
    else if(r.type == 2){
        out << "mRNA_exon" << endl;
    }
    else if(r.type == 3){
        out << "mRNA_intron" << endl;
    }
    else{
        out << "non RNA type" << endl;
    }
    return out;
}

istream&operator>> (istream& in, RNA& r)
{
    cout << " Enter The type: \n 1- mRNA.\n 2- pre_mRNA.\n 3- mRNA_exon.\n 4- mRNA_intron.";
    int TYPE;
    in >> TYPE;
    if(TYPE == 1){
        r.type = mRNA;
    }
    if(TYPE == 2){
        r.type = pre_mRNA;
    }
    if(TYPE == 3){
        r.type = mRNA_exon;
    }
    if(TYPE == 4){
        r.type = mRNA_intron;
    }
    int length;
    cout << " Enter the length of the sequence: ";
    in >> length;
    r.seq = new char[length];
    try
    {
        for(int i = 0; i < length; i++){
            in >> r.seq[i];
            if(r.seq[i] == 'A' || r.seq[i] == 'U' || r.seq[i] == 'G' || r.seq[i] == 'C'){
                r.seq[i+1] = '\0';
            }
            else{
                string error = " Wrong input!";
                throw error;
            }
        }
    }
    catch(string error)
    {
        cout << error << endl;
    }
    return in;
}

RNA RNA::operator= (RNA& r)
{
    seq = r.seq;
    type = r.type;
}

RNA RNA::operator+ (const RNA& r)
{
    if(type == r.type){
        RNA NewRNA("\0", type);
        strcat(NewRNA.seq, seq);
        strcat(NewRNA.seq, r.seq);
        return NewRNA;
    }
    else{
        cout << " The 2 RNA are not of the same type!" << endl;
    }
}

bool RNA::operator== (RNA& r)
{
    bool check = true;
    if(strlen(seq) != strlen(r.seq)){
        check = false;
    }
    else{
        for(int i = 0; i < strlen(seq); i++){
            if(seq[i] != r.seq[i]){
                check = false;
            }
        }
    }
    return check;
}

bool RNA::operator!= (RNA& r)
{
    bool check = true;
    if(strlen(seq) != strlen(r.seq)){
        check = true;
    }
    else{
        for(int i = 0; i < strlen(seq); i++){
            if(seq[i] == r.seq[i]){
                check = false;
            }
        }
    }
    return check;
}
