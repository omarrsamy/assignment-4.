#include "Sequence.h"
#include "DNA.h"
Sequence::Sequence()
{
    seq = new char[0];
}

Sequence::Sequence(int length)
{
    seq = new char[length];
}

Sequence::Sequence(Sequence& rhs)
{
    seq = new char[strlen(rhs.seq)];
    for(int i = 0; i < strlen(rhs.seq); i++){
        seq[i] = rhs.seq[i];
        seq[i+1] = '\0';
    }
}

Sequence::~Sequence()
{
    delete []seq;
}
